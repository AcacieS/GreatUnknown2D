using UnityEngine;

public class IceGridBehaviour : MonoBehaviour
{
    [Header("Grid Settings")]
    public int width = 10;
    public int height = 8;
    public float cellSize = 1f;
    public Vector2 origin = Vector2.zero;

    [Header("Tile Prefabs")]
    public GameObject wallPrefab;
    public GameObject icePrefab;   // for TileType.Empty
    public GameObject stopPrefab;
    public GameObject goalPrefab;  // optional

    [Header("Level (ASCII)")]
    [TextArea(6, 20)]
    public string level =
@"##########
#....S...#
#..##....#
#..P...G.#
#........#
##########";

    public IceGrid Grid { get; private set; }
    public Vector2Int PlayerStart { get; private set; }

    private Transform tilesParent;

    private void Awake()
    {
     BuildFromAscii(level);

    // 🔥 CENTER THE MAP
    origin = new Vector2(
        -width * cellSize / 2f,
        -height * cellSize / 2f
    );

    SpawnVisuals();
    }

    public Vector3 GridToWorldCenter(Vector2Int c)
    {
        return (Vector3)(origin + new Vector2((c.x + 0.5f) * cellSize, (c.y + 0.5f) * cellSize));
    }

    public Vector2Int WorldToGrid(Vector2 world)
    {
        Vector2 local = world - origin;
        int x = Mathf.FloorToInt(local.x / cellSize);
        int y = Mathf.FloorToInt(local.y / cellSize);
        return new Vector2Int(x, y);
    }

    private void BuildFromAscii(string ascii)
    {
        // Parse lines top->bottom; we’ll map top line to highest y
        var lines = ascii.Replace("\r", "").Split('\n');

        height = lines.Length;
        width = lines[0].Length;

        Grid = new IceGrid(width, height);

        for (int row = 0; row < height; row++)
        {
            string line = lines[row];
            int y = height - 1 - row; // top row becomes highest y

            for (int x = 0; x < width; x++)
            {
                char ch = line[x];
                Vector2Int c = new Vector2Int(x, y);

                switch (ch)
                {
                    case '#': Grid.Set(c, TileType.Wall); break;
                    case '.': Grid.Set(c, TileType.Empty); break;
                    case 'S': Grid.Set(c, TileType.Stop); break;
                    case 'G': Grid.Set(c, TileType.Goal); break;
                    case 'P':
                        Grid.Set(c, TileType.Empty);
                        PlayerStart = c;
                        break;
                    default:
                        Grid.Set(c, TileType.Empty);
                        break;
                }
            }
        }
    }

    private void SpawnVisuals()
    {
        if (tilesParent != null) Destroy(tilesParent.gameObject);
        tilesParent = new GameObject("Tiles").transform;
        tilesParent.SetParent(transform, false);

        for (int x = 0; x < Grid.Width; x++)
        for (int y = 0; y < Grid.Height; y++)
        {
            var c = new Vector2Int(x, y);
            var t = Grid.Get(c);

            GameObject prefab = t switch
            {
                TileType.Wall => wallPrefab,
                TileType.Stop => stopPrefab,
                TileType.Goal => goalPrefab != null ? goalPrefab : stopPrefab,
                _ => icePrefab
            };

            if (prefab == null) continue;

            var go = Instantiate(prefab, GridToWorldCenter(c), Quaternion.identity, tilesParent);
            go.name = $"{t} ({x},{y})";
        }
    }
}
