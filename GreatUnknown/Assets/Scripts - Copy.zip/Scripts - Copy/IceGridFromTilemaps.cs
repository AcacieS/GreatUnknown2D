using UnityEngine;
using UnityEngine.Tilemaps;

public enum TileType { Empty, Wall } // walls-only version

public class IceGrid
{
    public int Width { get; }
    public int Height { get; }
    private readonly TileType[,] tiles;

    public IceGrid(int width, int height)
    {
        Width = width;
        Height = height;
        tiles = new TileType[width, height];
    }

    public bool InBounds(Vector2Int c) =>
        c.x >= 0 && c.y >= 0 && c.x < Width && c.y < Height;

    public TileType Get(Vector2Int c) => tiles[c.x, c.y];
    public void Set(Vector2Int c, TileType t) => tiles[c.x, c.y] = t;

    private bool IsBlocked(Vector2Int c)
    {
        if (!InBounds(c)) return true;      // out of bounds acts like a wall
        return Get(c) == TileType.Wall;
    }

    public Vector2Int Slide(Vector2Int start, Vector2Int dir)
    {
        Vector2Int current = start;

        while (true)
        {
            Vector2Int next = current + dir;
            if (IsBlocked(next))
                return current;

            current = next;
        }
    }
}

public class IceGridFromTilemap : MonoBehaviour
{
    [Header("Tilemap Source")]
    public Tilemap wallsTilemap;

    [Header("Start")]
    public Transform startMarker; // Option A

    public IceGrid Grid { get; private set; }
    public Vector2Int PlayerStart { get; private set; }

    // We need a consistent origin and size for indexing.
    // We'll use the bounds of the wallsTilemap.
    public Vector3Int BoundsMin { get; private set; }  // bottom-left cell coordinate

    private void Awake()
    {
        BuildGridFromTilemap();
    }

    public void BuildGridFromTilemap()
    {
        if (wallsTilemap == null)
        {
            Debug.LogError("Assign wallsTilemap in inspector.");
            return;
        }

        BoundsInt b = wallsTilemap.cellBounds;
        // b.min is inclusive, b.max is exclusive
        BoundsMin = b.min;

        int gridWidth = b.size.x;
int gridHeight = b.size.y;

Grid = new IceGrid(gridWidth, gridHeight);

        Grid = new IceGrid(width, height);

        for (int x = 0; x < width; x++)
        for (int y = 0; y < height; y++)
        {
            Vector3Int cell = new Vector3Int(BoundsMin.x + x, BoundsMin.y + y, 0);
            bool hasWall = wallsTilemap.HasTile(cell);
            Grid.Set(new Vector2Int(x, y), hasWall ? TileType.Wall : TileType.Empty);
        }

        // Determine player start from marker
        if (startMarker != null)
        {
            Vector3Int startCell = wallsTilemap.WorldToCell(startMarker.position);
            PlayerStart = CellToGridIndex(startCell);
        }
        else
        {
            PlayerStart = new Vector2Int(0, 0);
            Debug.LogWarning("No startMarker assigned; defaulting PlayerStart to (0,0).");
        }
    }

    // Convert Tilemap cell coords -> our 0..width-1 indexing
    public Vector2Int CellToGridIndex(Vector3Int cell)
    {
        return new Vector2Int(cell.x - BoundsMin.x, cell.y - BoundsMin.y);
    }

    // Convert our indexing -> world center position of a cell
    public Vector3 GridIndexToWorldCenter(Vector2Int idx)
    {
        Vector3Int cell = new Vector3Int(BoundsMin.x + idx.x, BoundsMin.y + idx.y, 0);
        return wallsTilemap.GetCellCenterWorld(cell);
    }
}